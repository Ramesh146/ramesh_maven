package com.epam.anjanisukhavasi_oops.chocolates;

public class Galaxy extends Chocolate {

    public Galaxy(String name,int price,int weight){
        super(name,price,weight);
    }
}